<?php
define('URL','http://sms.iqyazilim.com/api/sms/');
define('SENDSINGLEBULK','v2/single');
define('SENDSPEED','v2/speed');
define('BALANCE','v1/balance');
define('REPORTS','v1/reports');

?>